# Scientific Computing with Python

This respository captures my personal solutions to the Scientific Computing with Python Certification projects.
- Arithmetic Formatter
- Time Calculator
- Budget App
- Polygon Area Calculator
- Probability Calculator
